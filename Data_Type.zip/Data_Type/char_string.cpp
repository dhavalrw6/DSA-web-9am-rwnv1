#include<iostream>
using namespace std;

int main(){

    //string array.
    char name[] = "Dhaval";

    cout<<name[0];
    cout<<name[1];
    cout<<name[2];
    cout<<name[3];

    return 0;
}