#include<iostream>
#define PI 3.14
using namespace std;


int main(){

    double area,r;

    cout<<"Enter r: ";
    cin>>r;

    area =  PI * r * r ;

    cout<<"area is: "<<area;

    return 0;
}