# Student Data
rollno
name
age

Enter roll No: 


roll no is: 1


# employee Data

emp_id
emp_name
emp_salary


