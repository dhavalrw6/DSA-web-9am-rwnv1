#include<iostream>
using namespace std;
int main() {

    int num = 10;
    float avg = 78.46;
    double davg = 73.78;
    char grade = 'A';
    char name[] = "John";
    string lastName = "Doe";

    cout<<"number is: "<<num<<endl;
    cout<<"avg is: "<<avg<<endl;
    cout<<"double avg is: "<<davg<<endl;
    cout<<"grade is: "<<grade<<endl;
    cout<<"name is: "<<name<<endl;
    cout<<"lastName is: "<<lastName<<endl;

    return 0;
}